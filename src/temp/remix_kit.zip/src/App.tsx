import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { 
  Globe, 
  Image as ImageIcon, 
  Download, 
  RefreshCw, 
  Loader2, 
  Sparkles, 
  ChevronDown, 
  Upload, 
  X, 
  Check, 
  Layers, 
  Languages,
  Zap,
  FileArchive,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import JSZip from 'jszip';

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey?: () => Promise<boolean>;
      openSelectKey?: () => Promise<void>;
    };
  }
}

const ASPECT_RATIOS = [
  { label: '16:9', value: '16:9', css: 'aspect-video' },
  { label: '1:1', value: '1:1', css: 'aspect-square' },
  { label: '9:16', value: '9:16', css: 'aspect-[9/16]' },
  { label: '4:3', value: '4:3', css: 'aspect-[4/3]' },
  { label: '3:4', value: '3:4', css: 'aspect-[3/4]' },
];

// Google-approved country list (ISO 3166-1)
const COUNTRIES = [
  'Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Antigua and Barbuda',
  'Argentina', 'Armenia', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain',
  'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan',
  'Bolivia', 'Bosnia and Herzegovina', 'Botswana', 'Brazil', 'Brunei', 'Bulgaria',
  'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cambodia', 'Cameroon', 'Canada',
  'Central African Republic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros',
  'Congo', 'Costa Rica', 'Croatia', 'Cuba', 'Cyprus', 'Czech Republic',
  'Democratic Republic of the Congo', 'Denmark', 'Djibouti', 'Dominica',
  'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea',
  'Eritrea', 'Estonia', 'Eswatini', 'Ethiopia', 'Fiji', 'Finland', 'France',
  'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Greece', 'Grenada', 'Guatemala',
  'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras', 'Hungary', 'Iceland',
  'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Jamaica',
  'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'Kuwait', 'Kyrgyzstan',
  'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein',
  'Lithuania', 'Luxembourg', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali',
  'Malta', 'Marshall Islands', 'Mauritania', 'Mauritius', 'Mexico', 'Micronesia',
  'Moldova', 'Monaco', 'Mongolia', 'Montenegro', 'Morocco', 'Mozambique', 'Myanmar',
  'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'New Zealand', 'Nicaragua', 'Niger',
  'Nigeria', 'North Korea', 'North Macedonia', 'Norway', 'Oman', 'Pakistan', 'Palau',
  'Palestine', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines',
  'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda', 'Saint Kitts and Nevis',
  'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino',
  'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia', 'Seychelles',
  'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia',
  'South Africa', 'South Korea', 'South Sudan', 'Spain', 'Sri Lanka', 'Sudan',
  'Suriname', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan', 'Tanzania',
  'Thailand', 'Timor-Leste', 'Togo', 'Tonga', 'Trinidad and Tobago', 'Tunisia',
  'Turkey', 'Turkmenistan', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates',
  'United Kingdom', 'United States', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Vatican City',
  'Venezuela', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe'
];

interface Result {
  market: string;
  loading: boolean;
  image: string | null;
  error: string | null;
}

export default function App() {
  const [hasKey, setHasKey] = useState(false);
  const [showKeyDialog, setShowKeyDialog] = useState(false);
  const [selectedMarkets, setSelectedMarkets] = useState<string[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadedReference, setUploadedReference] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [countrySearch, setCountrySearch] = useState('');
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [activeCountryIndex, setActiveCountryIndex] = useState(-1);
  const [culturalAdaptation, setCulturalAdaptation] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'comparison'>('grid');
  const [activeComparisonIndex, setActiveComparisonIndex] = useState(0);
  const [analysis, setAnalysis] = useState<{ text: string[]; elements: string[]; mood: string } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      } else {
        setHasKey(true); // Fallback if not in AI Studio
      }
    };
    checkKey();
  }, []);

  const analyzeImage = async (base64: string) => {
    setIsAnalyzing(true);
    try {
      const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
      if (!apiKey) return;

      const ai = new GoogleGenAI({ apiKey });
      const model = 'gemini-3.1-flash-lite-preview'; // Use lite for fast analysis
      
      const response = await ai.models.generateContent({
        model,
        contents: [
          {
            role: 'user',
            parts: [
              { inlineData: { mimeType: 'image/jpeg', data: base64 } },
              { text: "Analyze this advertisement image. Identify: 1. All visible text strings. 2. Key visual elements/objects. 3. The overall mood/aesthetic. Return as JSON with keys: 'text' (array), 'elements' (array), 'mood' (string)." }
            ]
          }
        ],
        config: { responseMimeType: 'application/json' }
      });

      if (response.text) {
        setAnalysis(JSON.parse(response.text));
      }
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSelectKey = async () => {
    if (window.aistudio?.openSelectKey) {
      try {
        await window.aistudio.openSelectKey();
        setHasKey(true);
        setShowKeyDialog(false);
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        setUploadedReference(base64);
        setAnalysis(null);
        analyzeImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateForMarket = async (market: string, refImage: string, ratio: string = '16:9'): Promise<string | null> => {
    try {
      const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
      if (!apiKey) throw new Error("API Key not found");

      const ai = new GoogleGenAI({ apiKey });
      const model = 'gemini-3.1-flash-image-preview';
      
      const adaptationPrompt = culturalAdaptation 
        ? `Translate all text in this advertisement image to the language of ${market}. 
           Context from image analysis:
           - Detected Text: ${analysis?.text.join(', ') || 'N/A'}
           - Key Elements: ${analysis?.elements.join(', ') || 'N/A'}
           - Mood: ${analysis?.mood || 'N/A'}
           
           Additionally, subtly adapt the visual elements, background, or models to be more culturally relevant and appealing to the ${market} market while maintaining the core brand identity, product placement, and overall composition. Ensure the final image feels native to ${market}.`
        : `Translate all text in this advertisement image to the language of ${market}. 
           Context from image analysis:
           - Detected Text: ${analysis?.text.join(', ') || 'N/A'}
           
           ONLY translate the text - do not add any cultural imagery, flags, national symbols, or stereotypical visual elements. Keep the image, composition, styling, colors, and all visual elements exactly the same as the original. The only change should be the language of the text.`;

      const contents = [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType: 'image/jpeg',
                data: refImage,
              },
            },
            {
              text: adaptationPrompt,
            },
          ],
        },
      ];

      const config = {
        responseModalities: ['IMAGE', 'TEXT'],
        aspectRatio: ratio,
      };

      const response = await ai.models.generateContent({
        model,
        config,
        contents,
      });

      let base64Image = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            base64Image = part.inlineData.data;
            break;
          }
        }
      }
      return base64Image;
    } catch (error) {
      console.error(`Error generating for ${market}:`, error);
      throw error;
    }
  };

  const handleGenerate = async () => {
    const keySelected = await window.aistudio?.hasSelectedApiKey();
    if (!keySelected) {
      setShowKeyDialog(true);
      return;
    }

    if (!uploadedReference || selectedMarkets.length === 0) return;

    setIsGenerating(true);
    setResults([]);

    try {
      const initialResults = selectedMarkets.map(m => ({
        market: m,
        loading: true,
        image: null,
        error: null
      }));
      setResults(initialResults);

      // Process in small batches to avoid hitting rate limits too hard
      const batchSize = 2;
      for (let i = 0; i < selectedMarkets.length; i += batchSize) {
        const batch = selectedMarkets.slice(i, i + batchSize);
        await Promise.all(
          batch.map(async (market) => {
            try {
              const image = await generateForMarket(market, uploadedReference, aspectRatio);
              setResults(prev => prev.map(r =>
                r.market === market
                  ? { ...r, loading: false, image, error: image ? null : 'Generation failed' }
                  : r
              ));
            } catch (err: any) {
              const msg = err.message || "";
              if (msg.includes("Requested entity was not found") || msg.includes("404")) {
                setShowKeyDialog(true);
              }
              setResults(prev => prev.map(r =>
                r.market === market
                  ? { ...r, loading: false, error: 'API Error' }
                  : r
              ));
            }
          })
        );
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExportZip = async () => {
    if (results.length === 0) return;
    setIsExporting(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder("localized_assets");
      
      results.forEach((res) => {
        if (res.image) {
          folder?.file(`${res.market.toLowerCase().replace(/\s+/g, '_')}.jpg`, res.image, { base64: true });
        }
      });

      const content = await zip.generateAsync({ type: "blob" });
      const url = window.URL.createObjectURL(content);
      const a = document.createElement("a");
      a.href = url;
      a.download = `global_kit_${new Date().getTime()}.zip`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Export failed:", error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleReset = () => {
    setSelectedMarkets([]);
    setResults([]);
    setUploadedReference(null);
    setCountrySearch('');
  };

  return (
    <main className="flex flex-col lg:flex-row min-h-screen bg-[#fcfcfc] text-[#1a1a1a] font-sans selection:bg-[#000] selection:text-[#fff]">
      {/* Left Sidebar - Configuration */}
      <div className="w-full lg:w-[400px] xl:w-[450px] border-r border-[#e5e5e5] bg-white p-6 lg:p-8 flex flex-col h-screen overflow-hidden sticky top-0">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-8 h-8 bg-[#000] rounded-lg flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">Global Kit</h1>
            <p className="text-[9px] uppercase tracking-widest font-bold text-gray-400">Asset Localizer v2.0</p>
          </div>
        </div>

        <div className="space-y-8 flex-1 overflow-y-auto no-scrollbar pr-2">
          {/* Step 1: Upload */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <label className="text-[11px] font-bold uppercase tracking-[0.15em] text-gray-500">01. Master Concept</label>
              {uploadedReference && (
                <button onClick={() => setUploadedReference(null)} className="text-[10px] font-bold text-red-500 hover:underline">Clear</button>
              )}
            </div>
            
            {uploadedReference ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative group rounded-2xl overflow-hidden border border-[#e5e5e5] bg-gray-50"
              >
                <img
                  src={`data:image/jpeg;base64,${uploadedReference}`}
                  alt="Master concept"
                  className="w-full aspect-video object-cover"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button 
                    onClick={() => {
                      setUploadedReference(null);
                      setAnalysis(null);
                    }}
                    className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2"
                  >
                    <RefreshCw className="w-3 h-3" /> Replace
                  </button>
                </div>
              </motion.div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full aspect-video border-2 border-dashed border-[#e5e5e5] rounded-2xl cursor-pointer hover:border-black hover:bg-gray-50 transition-all group">
                <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Upload className="w-5 h-5 text-gray-400" />
                </div>
                <span className="text-sm font-medium text-gray-600">Drop master asset here</span>
                <span className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest">JPG, PNG up to 10MB</span>
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>
            )}

            {/* Analysis Results */}
            <AnimatePresence>
              {(isAnalyzing || analysis) && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 p-4 bg-[#f3f3f3] rounded-2xl border border-[#e5e5e5] overflow-hidden"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <Eye className="w-3 h-3 text-gray-400" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Rendering Analysis</span>
                    {isAnalyzing && <Loader2 className="w-3 h-3 animate-spin ml-auto" />}
                  </div>
                  
                  {isAnalyzing ? (
                    <div className="space-y-2">
                      <div className="h-2 w-full bg-gray-200 rounded animate-pulse" />
                      <div className="h-2 w-3/4 bg-gray-200 rounded animate-pulse" />
                    </div>
                  ) : analysis && (
                    <div className="space-y-3">
                      <div>
                        <p className="text-[9px] font-bold text-gray-400 uppercase mb-1">Detected Text</p>
                        <div className="flex flex-wrap gap-1">
                          {analysis.text.map((t, i) => (
                            <span key={i} className="px-1.5 py-0.5 bg-white rounded text-[9px] border border-gray-200">{t}</span>
                          ))}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-[9px] font-bold text-gray-400 uppercase mb-1">Elements</p>
                          <p className="text-[10px] leading-tight">{analysis.elements.join(', ')}</p>
                        </div>
                        <div>
                          <p className="text-[9px] font-bold text-gray-400 uppercase mb-1">Mood</p>
                          <p className="text-[10px] leading-tight">{analysis.mood}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </section>

          {/* Step 2: Markets */}
          <section>
            <label className="block text-[11px] font-bold uppercase tracking-[0.15em] text-gray-500 mb-4">02. Target Markets</label>
            
            <div className="relative">
              <div className="flex flex-wrap gap-2 mb-4">
                <AnimatePresence>
                  {selectedMarkets.map((market) => (
                    <motion.span
                      key={market}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#f3f3f3] hover:bg-[#e5e5e5] text-black text-xs font-medium rounded-full transition-colors group"
                    >
                      {market}
                      <button
                        onClick={() => setSelectedMarkets(prev => prev.filter(m => m !== market))}
                        className="text-gray-400 hover:text-black transition-colors"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </motion.span>
                  ))}
                </AnimatePresence>
              </div>

              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                  <Globe className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  className="w-full bg-[#f3f3f3] border-none rounded-xl py-3 pl-11 pr-4 text-sm focus:ring-2 focus:ring-black transition-all placeholder:text-gray-400"
                  placeholder="Search countries..."
                  value={countrySearch}
                  onChange={(e) => {
                    setCountrySearch(e.target.value);
                    setShowCountryDropdown(true);
                    setActiveCountryIndex(-1);
                  }}
                  onFocus={() => setShowCountryDropdown(true)}
                  onBlur={() => setTimeout(() => setShowCountryDropdown(false), 200)}
                />

                {showCountryDropdown && countrySearch && (
                  <div className="absolute z-50 w-full mt-2 bg-white border border-[#e5e5e5] rounded-xl shadow-2xl max-h-60 overflow-y-auto p-1">
                    {COUNTRIES
                      .filter(country =>
                        country.toLowerCase().includes(countrySearch.toLowerCase()) &&
                        !selectedMarkets.includes(country)
                      )
                      .slice(0, 10)
                      .map((country, idx) => (
                        <button
                          key={country}
                          className={`w-full px-4 py-2.5 text-left text-sm rounded-lg transition-colors ${
                            activeCountryIndex === idx ? 'bg-black text-white' : 'hover:bg-gray-50'
                          }`}
                          onClick={() => {
                            setSelectedMarkets(prev => [...prev, country]);
                            setCountrySearch('');
                            setShowCountryDropdown(false);
                          }}
                        >
                          {country}
                        </button>
                      ))}
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* Step 3: Configuration */}
          <section className="space-y-6">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-[0.15em] text-gray-500 mb-4">03. Format & Logic</label>
              <div className="grid grid-cols-3 gap-2">
                {ASPECT_RATIOS.map(ar => (
                  <button
                    key={ar.value}
                    onClick={() => setAspectRatio(ar.value)}
                    className={`py-2 rounded-lg border text-[10px] font-bold uppercase tracking-widest transition-all ${
                      aspectRatio === ar.value 
                        ? 'bg-black border-black text-white shadow-lg shadow-black/10' 
                        : 'bg-white border-[#e5e5e5] text-gray-500 hover:border-black hover:text-black'
                    }`}
                  >
                    {ar.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 bg-[#f3f3f3] rounded-2xl flex items-center justify-between group cursor-pointer" onClick={() => setCulturalAdaptation(!culturalAdaptation)}>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${culturalAdaptation ? 'bg-black text-white' : 'bg-white text-gray-400'}`}>
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest">Cultural Adaptation</p>
                  <p className="text-[10px] text-gray-500">Enable AI visual localization</p>
                </div>
              </div>
              <div className={`w-10 h-5 rounded-full relative transition-colors ${culturalAdaptation ? 'bg-black' : 'bg-gray-300'}`}>
                <motion.div 
                  animate={{ x: culturalAdaptation ? 22 : 2 }}
                  className="absolute top-1 w-3 h-3 bg-white rounded-full"
                />
              </div>
            </div>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-[#e5e5e5]">
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !uploadedReference || selectedMarkets.length === 0}
            className="w-full py-4 bg-black text-white rounded-xl font-bold text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-3 disabled:opacity-30 hover:bg-black/90 active:scale-[0.98] transition-all shadow-xl shadow-black/10"
          >
            {isGenerating ? (
              <>
                <Loader2 className="animate-spin w-4 h-4" />
                Localizing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Generate Kit
              </>
            )}
          </button>
          <p className="text-[9px] text-center text-gray-400 mt-4 uppercase tracking-widest">Powered by Gemini 3.1 Flash Image</p>
        </div>
      </div>

      {/* Right Content - Results */}
      <div className="flex-1 flex flex-col bg-[#fcfcfc] h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-[#e5e5e5] bg-white/80 backdrop-blur px-6 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-6">
            <div className="flex bg-[#f3f3f3] p-1 rounded-lg">
              <button 
                onClick={() => setViewMode('grid')}
                className={`px-3 py-1 rounded-md text-[9px] font-bold uppercase tracking-widest transition-all ${viewMode === 'grid' ? 'bg-white text-black shadow-sm' : 'text-gray-400 hover:text-black'}`}
              >
                Grid
              </button>
              <button 
                onClick={() => setViewMode('comparison')}
                className={`px-3 py-1 rounded-md text-[9px] font-bold uppercase tracking-widest transition-all ${viewMode === 'comparison' ? 'bg-white text-black shadow-sm' : 'text-gray-400 hover:text-black'}`}
              >
                Compare
              </button>
            </div>
            {results.length > 0 && (
              <div className="h-4 w-px bg-gray-200" />
            )}
            {results.length > 0 && (
              <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400">
                {results.filter(r => !r.loading && r.image).length} / {results.length} Ready
              </p>
            )}
          </div>

          <div className="flex items-center gap-2">
            {results.length > 0 && (
              <>
                <button 
                  onClick={handleReset}
                  className="p-2 text-gray-400 hover:text-black hover:bg-gray-100 rounded-lg transition-all"
                  title="Reset All"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleExportZip}
                  disabled={isExporting || results.every(r => r.loading || !r.image)}
                  className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-[9px] font-bold uppercase tracking-widest hover:bg-black/90 disabled:opacity-30 transition-all shadow-lg shadow-black/5"
                >
                  {isExporting ? <Loader2 className="w-3 h-3 animate-spin" /> : <FileArchive className="w-3 h-3" />}
                  Export Kit
                </button>
              </>
            )}
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-6 lg:p-8">
          {results.length > 0 ? (
            viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                <AnimatePresence mode="popLayout">
                  {results.map((res, i) => (
                    <motion.div
                      key={res.market}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="group flex flex-col bg-white rounded-2xl border border-[#e5e5e5] overflow-hidden hover:shadow-2xl hover:shadow-black/5 transition-all"
                    >
                      <div className="p-4 border-b border-[#e5e5e5] flex items-center justify-between bg-gray-50/50">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-black" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">{res.market}</span>
                        </div>
                        {res.image && !res.loading && (
                          <button 
                            onClick={() => {
                              const a = document.createElement('a');
                              a.href = `data:image/jpeg;base64,${res.image}`;
                              a.download = `${res.market.toLowerCase()}.jpg`;
                              a.click();
                            }}
                            className="text-gray-400 hover:text-black transition-colors"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                      
                      <div className="relative aspect-square bg-[#f3f3f3] flex items-center justify-center overflow-hidden">
                        {res.loading ? (
                          <div className="flex flex-col items-center gap-3">
                            <Loader2 className="w-6 h-6 animate-spin text-gray-300" />
                            <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-gray-400 animate-pulse">Processing</p>
                          </div>
                        ) : res.error ? (
                          <div className="p-6 text-center">
                            <X className="w-6 h-6 text-red-500 mx-auto mb-2" />
                            <p className="text-[10px] font-bold uppercase tracking-widest text-red-500">{res.error}</p>
                          </div>
                        ) : (
                          <motion.img 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            src={`data:image/jpeg;base64,${res.image}`} 
                            alt={res.market} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                          />
                        )}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            ) : (
              <div className="h-full flex flex-col gap-8">
                <div className="flex-1 grid grid-cols-2 gap-8 items-center">
                  <div className="space-y-4">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Master Concept</p>
                    <div className="rounded-3xl overflow-hidden border border-[#e5e5e5] bg-white shadow-2xl shadow-black/5">
                      <img src={`data:image/jpeg;base64,${uploadedReference}`} className="w-full aspect-square object-cover" alt="Master" />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Localized: {results[activeComparisonIndex]?.market}</p>
                      <div className="flex gap-1">
                        {results.map((_, idx) => (
                          <button 
                            key={idx}
                            onClick={() => setActiveComparisonIndex(idx)}
                            className={`w-1.5 h-1.5 rounded-full transition-all ${activeComparisonIndex === idx ? 'bg-black w-4' : 'bg-gray-200'}`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="rounded-3xl overflow-hidden border border-[#e5e5e5] bg-white shadow-2xl shadow-black/5 relative aspect-square flex items-center justify-center">
                      {results[activeComparisonIndex]?.loading ? (
                        <div className="flex flex-col items-center gap-3">
                          <Loader2 className="w-8 h-8 animate-spin text-gray-300" />
                          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 animate-pulse">Processing</p>
                        </div>
                      ) : results[activeComparisonIndex]?.image ? (
                        <motion.img 
                          key={activeComparisonIndex}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          src={`data:image/jpeg;base64,${results[activeComparisonIndex].image}`} 
                          className="w-full h-full object-cover" 
                          alt="Localized" 
                        />
                      ) : (
                        <div className="text-center p-8">
                          <ImageIcon className="w-12 h-12 text-gray-100 mx-auto mb-4" />
                          <p className="text-xs text-gray-400">Select a market to compare</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                  {results.map((res, idx) => (
                    <button
                      key={res.market}
                      onClick={() => setActiveComparisonIndex(idx)}
                      className={`flex-shrink-0 w-24 h-24 rounded-xl overflow-hidden border-2 transition-all ${activeComparisonIndex === idx ? 'border-black scale-105' : 'border-transparent opacity-50 hover:opacity-100'}`}
                    >
                      {res.image ? (
                        <img src={`data:image/jpeg;base64,${res.image}`} className="w-full h-full object-cover" alt={res.market} />
                      ) : (
                        <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                          <Globe className="w-4 h-4 text-gray-300" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto">
              <div className="w-24 h-24 bg-white rounded-3xl shadow-2xl shadow-black/5 flex items-center justify-center mb-8 border border-[#e5e5e5]">
                <Layers className="w-8 h-8 text-gray-200" />
              </div>
              <h2 className="text-2xl font-bold tracking-tight mb-3">Scale your vision.</h2>
              <p className="text-sm text-gray-500 leading-relaxed mb-8">
                Upload your master creative and select target markets. Our AI engine will generate pixel-perfect localized assets in seconds.
              </p>
              <div className="grid grid-cols-2 gap-4 w-full">
                <div className="p-4 bg-white rounded-2xl border border-[#e5e5e5] text-left">
                  <Languages className="w-5 h-5 mb-3 text-black" />
                  <p className="text-[10px] font-bold uppercase tracking-widest mb-1">Translation</p>
                  <p className="text-[10px] text-gray-400">Context-aware text localization</p>
                </div>
                <div className="p-4 bg-white rounded-2xl border border-[#e5e5e5] text-left">
                  <Sparkles className="w-5 h-5 mb-3 text-black" />
                  <p className="text-[10px] font-bold uppercase tracking-widest mb-1">Adaptation</p>
                  <p className="text-[10px] text-gray-400">Cultural visual refinement</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showKeyDialog && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="max-w-md w-full bg-white rounded-[32px] shadow-2xl border border-black/5 p-10 text-center"
            >
              <div className="w-20 h-20 mx-auto bg-[#f3f3f3] rounded-3xl flex items-center justify-center mb-8">
                <Zap className="w-8 h-8 text-black" />
              </div>
              <h2 className="text-2xl font-bold tracking-tight mb-4">API Key Required</h2>
              <p className="text-sm text-gray-500 leading-relaxed mb-10">
                To access Gemini 3.1 Flash Image and generate high-fidelity localized assets, please select a valid API key from your AI Studio account.
              </p>
              <div className="space-y-3">
                <button
                  onClick={handleSelectKey}
                  className="w-full py-4 bg-black text-white font-bold text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-black/90 transition-all shadow-xl shadow-black/10"
                >
                  Select API Key
                </button>
                <button
                  onClick={() => setShowKeyDialog(false)}
                  className="w-full py-3 text-gray-400 text-[10px] uppercase tracking-[0.2em] font-bold hover:text-black transition-colors"
                >
                  Dismiss
                </button>
              </div>
              <p className="mt-8 text-[9px] text-gray-300 uppercase tracking-widest">Billing required for Imagen models</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
